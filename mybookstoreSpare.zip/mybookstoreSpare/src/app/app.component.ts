import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my bookstore app';
  
    // Object to save the response returned from the service.
  myresponse: any;
 
  // Url to fetch the customer records from the spring application.
  readonly APP_URL = 'http://localhost:8088/rest';
 
  constructor(private _http: HttpClient) { }
 
  // Method to fetch all customers from the database table.
  getall() {
    this._http.get(this.APP_URL + '/viewAll').subscribe(
      data => {
        this.myresponse = data;
      },
      error => {
        console.log('Error occured', error);
      }
    );
  }
  
    getprofiledetails(mobile, customerPassword) {
		
    this._http.get(this.APP_URL + '/viewCustomerProfile/'+mobile+"/"+customerPassword).subscribe(
      data => {
        this.myresponse = data;
      },
      error => {
        console.log('Error occured', error);
      }
    );
  }
  
  
  
}
