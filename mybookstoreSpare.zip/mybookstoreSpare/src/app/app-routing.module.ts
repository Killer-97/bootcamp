import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import {ViewProfileComponent} from './customer/viewprofile.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
const routes: Routes = [
 { path: 'home', component: HomeComponent},
 
 { path: 'customers', component: CustomerComponent},
  { path: 'customerprofile', component: ViewProfileComponent},
    { path: 'login', component:LoginComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
