import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Customer } from '../models/customer.model';
import { CustomerService } from './customer.service';

@Component({
	selector:'view-root',
  templateUrl: './viewprofile.component.html',
  styleUrls: ['./customer.component.css']
})



export class ViewProfileComponent{

customer : Customer;

  constructor(private router: Router,private customerService: CustomerService){
  
}
  getProfile(data){
    this.customerService.getProfile(data).subscribe( data => {
        this.customer = data;
      });
  };
	
	
}