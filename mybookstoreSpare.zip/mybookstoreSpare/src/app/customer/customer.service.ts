import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from '../models/customer.model';
 import { FormsModule } from '@angular/forms';
 
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 
@Injectable()
export class CustomerService {
 
  constructor(private http:HttpClient) {}
 
  private customerUrl = 'http://localhost:8088/rest/viewAll';
 
  public getAllCustomers() {
    return this.http.get<Customer[]>(this.customerUrl);
  }
  


private viewProfileUrl = 'http://localhost:8088/rest/viewCustomerProfile';
 
  public getProfile(data) {
    return this.http.get<Customer>(this.viewProfileUrl+"/"+data);
  }
  
  
 
}