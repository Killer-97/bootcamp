package com.cg.evergreenbookstorewithrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.evergreenbookstorewithrest.bean.Customer;
import com.cg.evergreenbookstorewithrest.service.CustomerService;

@RestController
@RequestMapping("/rest")
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@RequestMapping("/")
	public String Home() {
		return "welcome to EVERE GREEN BOOKSTORE";
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/viewCustomerProfile/{mobile}")
	public Customer viewAllUsers(@PathVariable String mobile) {
		Customer c = customerService.findBycustomerMobile(mobile);
		return c;
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/viewAll")
	public List<Customer> viewAllUsers() {
		List<Customer> list = customerService.getAllCustomers();
		return list;
	}
	
	 @PutMapping("/edit/{mobile}") 
	 public boolean editCustomerProfile(@RequestBody Customer c, @PathVariable String mobile) {
		 Customer getOldDetails =customerService.findBycustomerMobile(mobile);
		 
		 getOldDetails=c;
		 
		 return  customerService.updateProfile(getOldDetails);
		
	}
	
	
}
