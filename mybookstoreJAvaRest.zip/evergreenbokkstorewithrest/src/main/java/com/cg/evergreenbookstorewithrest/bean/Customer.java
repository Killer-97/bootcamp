package com.cg.evergreenbookstorewithrest.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "bookstore_customer")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eg")
	@SequenceGenerator(name = "eg", sequenceName = "eg", initialValue = 1, allocationSize = 1)
	private int id;
	
	private String customerName;

	private String customerMobile;
	
	private String customerPassword;
	
	private String customerEmail;
	
	private String customerAddress;
	
	private String city;
	
	private String zipcode;
	
	private String country;

	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Customer(String customerName, String customerMobile, String customerPassword, String customerEmail,
			String customerAddress, String city, String zipcode, String country) {
		super();
		this.customerName = customerName;
		this.customerMobile = customerMobile;
		this.customerPassword = customerPassword;
		this.customerEmail = customerEmail;
		this.customerAddress = customerAddress;
		this.city = city;
		this.zipcode = zipcode;
		this.country = country;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public String getCustomerMobile() {
		return customerMobile;
	}



	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}



	public String getCustomerPassword() {
		return customerPassword;
	}



	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}



	public String getCustomerEmail() {
		return customerEmail;
	}



	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}



	public String getCustomerAddress() {
		return customerAddress;
	}



	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getZipcode() {
		return zipcode;
	}



	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}



	public String getCountry() {
		return country;
	}



	public void setCountry(String country) {
		this.country = country;
	}



	@Override
	public String toString() {
		return "Customer [id=" + id + ", customerName=" + customerName + ", customerMobile=" + customerMobile
				+ ", customerPassword=" + customerPassword + ", customerEmail=" + customerEmail + ", customerAddress="
				+ customerAddress + ", city=" + city + ", zipcode=" + zipcode + ", country=" + country + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
