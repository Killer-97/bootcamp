import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my bookstore app';
  
    // Object to save the response returned from the service.
  myresponse: any;
 
  // Url to fetch the customer records from the spring application.
  readonly APP_URL = 'http://localhost:8088/rest';
 
  constructor(private _http: HttpClient) { }
 
  // Method to fetch all customers from the database table.
  getall() {
    this._http.get(this.APP_URL + '/viewAll').subscribe(
      data => {
        this.myresponse = data;
      },
      error => {
        console.log('Error occured', error);
      }
    );
  }
  
    getprofiledetails() {
    this._http.get(this.APP_URL + '/viewCustomerProfile/8886091433').subscribe(
      data => {
        this.myresponse = data;
      },
      error => {
        console.log('Error occured', error);
      }
    );
  }
  
  
  
}
