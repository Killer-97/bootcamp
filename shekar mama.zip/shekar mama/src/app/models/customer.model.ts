export class Customer{
id:number;
customerName:string;
customerMobile:string;
customerPassword:string;
customerEmail:string;
customerAddress

city:string;
zipcode:string;
country:string;
}
