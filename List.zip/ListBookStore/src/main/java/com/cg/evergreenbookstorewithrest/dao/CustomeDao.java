package com.cg.evergreenbookstorewithrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.evergreenbookstorewithrest.bean.Customer;

@Repository("customerDao")
public interface CustomeDao extends JpaRepository<Customer, String> {
	
	public Customer findBycustomerMobile(String customerMobile);

}
