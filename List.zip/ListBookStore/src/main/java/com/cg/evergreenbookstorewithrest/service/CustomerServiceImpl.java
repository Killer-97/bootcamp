package com.cg.evergreenbookstorewithrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.evergreenbookstorewithrest.bean.Customer;
import com.cg.evergreenbookstorewithrest.dao.CustomeDao;


@Service("customerService")
public class CustomerServiceImpl implements CustomerService{

	
	@Autowired
	CustomeDao customerDao;
	@Override
	public Customer findBycustomerMobile(String Mobile) {
		
		
		return customerDao.findBycustomerMobile(Mobile);
	}
	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.findAll();
	}
	@Override
	public boolean updateProfile(Customer customer) {
		Customer uc=null;
		uc	= customerDao.save(customer);
		if(uc!=null ) {
			return true;
		}
		return false;
	}

}
