package com.cg.evergreenbookstorewithrest.service;

import java.util.List;

import com.cg.evergreenbookstorewithrest.bean.Customer;

public interface CustomerService {


public Customer findBycustomerMobile(String Mobile);

public List<Customer> getAllCustomers();

public boolean updateProfile(Customer customer);


}
