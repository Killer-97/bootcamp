package com.cg.controller;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.model.Customers;
import com.cg.service.ICustomerService;

@RestController
@RequestMapping("/rest")
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {

	@Autowired
	ICustomerService iCustomerService;

	List<Customers> cartlist = new ArrayList<Customers>();

	@RequestMapping("/addToCart/{CustomerId}")
	public Customers addToCart(@PathVariable("CustomerId")int CustomerId) {
		Customers Customer = iCustomerService.findCustomerById(CustomerId);
		cartlist.add(Customer);
		return Customer;
		//return "added to cart";
	}

	@RequestMapping(value="/delete from cart/{CustomerId}" , method = RequestMethod.DELETE)
	public List<Customers> deleteFromCart(@PathVariable("CustomerId") int CustomerId) {
		for (Customers Customer1 : cartlist) {
			if (Customer1.getCustomerId() == CustomerId) {
				cartlist.remove(Customer1);
			}
			System.out.println("deleted Customer");
		}
		return cartlist;
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping( method = RequestMethod.GET,value =  "/viewCart")
	public List<Customers> view_Cart() {
		return iCustomerService.getAll();
	}
}
