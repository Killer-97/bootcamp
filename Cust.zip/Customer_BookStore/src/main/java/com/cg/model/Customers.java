package com.cg.model;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;


@Entity
@Component
@Table(name="Customer_bookstore")
public class Customers{// implements Serializable {
	/**
	 * 
	 */
	
	@Id
	@GeneratedValue(generator="customer",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="customer",sequenceName="customer1",initialValue=1,allocationSize=1)
	private	int Sno;
	private	int customerId;
	private	String FullName;
	private String EmailId;
    private LocalDate RegistrationDate;
    private String City;
    private String Country;
		
	
	
	public int getSno() {
		return Sno;
	}
	public void setSno(int sno) {
		Sno = sno;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getFullName() {
		return FullName;
	}
	public void setFullName(String fullName) {
		FullName = fullName;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public LocalDate getRegistrationDate() {
		return RegistrationDate;
	}
	public void setRegistrationDate(LocalDate registrationDate) {
		RegistrationDate = registrationDate;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	
	public Customers(int sno, int customerId, String fullName, String emailId, LocalDate registrationDate, String city,
			String country) {
		super();
		Sno = sno;
		this.customerId = customerId;
		FullName = fullName;
		EmailId = emailId;
		RegistrationDate = registrationDate;
		City = city;
		Country = country;
	}
	public Customers() {
		super();
	}
	@Override
	public String toString() {
		return "Customers [Sno=" + Sno + ", customerId=" + customerId + ", FullName=" + FullName + ", EmailId="
				+ EmailId + ", RegistrationDate=" + RegistrationDate + ", City=" + City + ", Country=" + Country + "]";
	}
	

	
	
	
    
}
