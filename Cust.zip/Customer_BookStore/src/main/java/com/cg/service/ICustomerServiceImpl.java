package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDao;
import com.cg.model.Customers;

@Service("iCustomerService")
public class ICustomerServiceImpl implements ICustomerService{

	private static final ICustomerDao iCustomerDao = null;
	@Autowired
	ICustomerDao iBookDao;

	public Customers findBookById(int id) {
		// TODO Auto-generated method stub
				Customers customer = iBookDao.findByCustomerId(id);
				if (customer != null) {
					return customer;
				} else {
					return customer;
				}
	}

	public List<Customers> getAll() {
		// TODO Auto-generated method stub
		return iCustomerDao.findAll();
	}

	public Customers findCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customers findCustomerById1(int id) {
		// TODO Auto-generated method stub
		return null;
	}
}
